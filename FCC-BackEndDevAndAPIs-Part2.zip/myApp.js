let express = require('express');
let app = express();
let bodyParser = require('body-parser');

// middleware function mouted at all addresses logging the method, path and IP
app.use(function middleware(req, res, next) {
  console.log(req.method + " " + req.path + " - " + req.ip);
  next();}
);

app.use(bodyParser.urlencoded({extended: false}));

// console log hello world
console.log('Hello World');

/*
app.get("/", function(req,res) {
  res.send("Hello Express");
});
*/

// serve an HTML file
app.get("/", function(req,res) {
  res.sendFile(__dirname + "/views/index.html");
});

// serve a json object using the environment variable MESSAGE_STYLE
app.get("/json", function(req,res) {
  if (process.env.MESSAGE_STYLE === "uppercase") {
    res.json({"message": "HELLO JSON"});
  } else {
    res.json({"message": "Hello json"});
  };
});

// serve static assets
app.use("/public", express.static(__dirname + "/public"));

// serve time of now in json object
app.get("/now", function(req, res, next) {
  req.time = new Date().toString();
  next();
}, function(req, res) {
  res.json({time: req.time});
});

// echo server
app.get("/:word/echo", function(req, res, next) {
  res.json({echo: req.params.word});
  next();
});

// get query parameters
app.route("/name").get(function(req, res, next) {
  var { first: firstName, last: lastName } = req.query;
  res.json({name: `${firstName} ${lastName}`});
  next();
}).post(function(req, res, next) {
  var { first: firstName, last: lastName } = req.body;
  res.json({name: `${firstName} ${lastName}`});
  next();
});

// export the app
module.exports = app;
